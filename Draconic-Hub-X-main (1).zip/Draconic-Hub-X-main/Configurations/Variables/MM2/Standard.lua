local DConfiguration = {
  ESP = {
    Innocent = false,
    Sheriff = false,
    Murderer = false,
  },

  Tracers = {
    Innocent = false,
    Sheriff = false,
    Murderer = false,
  },

  Boxes = {
    Innocent = false,
    Sheriff = false,
    Murderer = false,
  },
  
  SpoofRole = {
    Murderer = false,
    Sheriff = false,
    Perks = false,
    Yourself = false,
  },

  
  
}

return DConfiguration
